<?php

/**
 * @Project NUKEVIET 3.x
 * @Author DANGDINHTU (contact@tdweb.vn)
 * @Copyright (C) 2013 tdweb.vn
 * @Createdate Wed, 28 Aug 2013 10:36:42 ICT 
 */

define( "NV_MAINFILE", true );

if ( ! defined( 'NV_ROOTDIR' ) ) define( 'NV_ROOTDIR', preg_replace( "/[\/]+$/", '', str_replace( '\\', '/', realpath( dirname( __file__ ) . "/" ) ) ) );

$global_config = $db_config = $sys_info = array();
$global_config['version'] = "3.4.02";
$sys_info['ftp_support'] = false;
$db_config['new_link'] = false;
$db_config['persistency'] = false;

$sys_info['mb_support'] = ( extension_loaded( 'mbstring' ) ) ? 1 : 0;
$sys_info['iconv_support'] = ( extension_loaded( 'iconv' ) ) ? 1 : 0;
$sys_info['string_handler'] = $sys_info['mb_support'] ? 'mb' : ( $sys_info['iconv_support'] ? 'iconv' : 'php' );


require_once ( NV_ROOTDIR . "/includes/constants.php" );

require_once ( realpath( NV_ROOTDIR . "/" . NV_CONFIG_FILENAME ) );
require_once ( NV_ROOTDIR . "/includes/class/mysql.class.php" );
require_once ( NV_ROOTDIR . '/includes/functions.php' );
require_once ( NV_ROOTDIR . "/includes/core/filesystem_functions.php" );


$db = new sql_db( $db_config );
if ( ! empty( $db->error ) )
{
    $die = ! empty( $db->error['user_message'] ) ? $db->error['user_message'] : $db->error['message'];
    $die .= ! empty( $db->error['code'] ) ? ' (Code: ' . $db->error['code'] . ')' : '';
    trigger_error( $die, 256 );
}
unset( $db_config['dbpass'] );


define( 'NV_CONFIG_GLOBALTABLE', $db_config['prefix'] . '_config' );

$sql = "SELECT * FROM " . NV_CONFIG_GLOBALTABLE . " WHERE `lang`='sys'";
$result = $db->sql_query( $sql );
$text = "<?php\n
/**
 * @Project NUKEVIET 3.x
 * @Author ĐẶNG ĐÌNH TỨ (contact@tdweb.vn)
 * @Copyright (C) " . date( "Y" ) . " tdweb.vn
 * @Createdate " . date( "D, j M Y G:i:s T " ) . "
 */\n\n\nif ( ! defined( 'NV_MAINFILE' ) ) die( 'Stop!!!' );\n\n";

while( $item = $db->sql_fetch_assoc( $result ) )
{
	if( is_numeric( $item['config_value'] ) ) $value = intval( $item['config_value'] );
	else  $value = $db->dbescape_string( $item['config_value'] );
	$text .= "\$global_config['" . $item['config_name'] . "'] = " . $value . ";\n";
}
$text .= "\n?>";
file_put_contents( NV_ROOTDIR . "/" . NV_DATADIR . "/config_global.php", $text );

$check = nv_deletefile( NV_ROOTDIR . "/create_config.php" );
if( $check )
{
	$content = "<div style='padding-top:50px;font-weight:bold;width:980px;margin:0 auto;font-size:20px;text-align:center;color:red'>Quá trình tạo file 'config_global.php' thành công. File 'create_config.php' đã tự động được xóa khỏi hệ thống !<br />";
	$content .= "Create Successful The file 'config_global.php'. File 'create_config.php' were automatically deleted from the system !</div>";
}
else
{
	$content = "<div style='padding-top:50px;font-weight:bold;width:980px;margin:0 auto;font-size:20px;text-align:center;color:red'>Quá trình tạo file 'config_global.php' thành công. Bạn hãy xóa file 'create_config.php' ngay lập tức !<br />";
	$content .= "Create Successful The file 'config_global.php'. You should remove 'create_config.php' Now !</div>";
}
die( $content );

?>